# App 0.6.0: Einbau und Prüfstand

Das App-Archiv enthält `novaspace_platform/`, die Quellen und die AGPL-Lizenz.
Vor Verwendung die SHA-256-Prüfsumme prüfen und außerhalb der Cloud entpacken.
Die enthaltene Gateway-Konfiguration ist inaktiv; eine vorhandene eigene
`appinfo/trusted-gateway.json` installationsbezogen erhalten.

## Update einer vorhandenen App 0.5.0

Quelle, Versionsmetadaten, Aktivierung, eigene Vertrauenskonfiguration sowie
Datenbank sichern und prüfen. Danach die geprüften Programmdateien im bestehenden
Apppfad bereitstellen und das native Nextcloud-App-Upgrade für die Version0.6.0
verwenden. Das Update fügt gegenüber0.5.0 keine Migration oder Tabelle hinzu;
alle sieben Plattformtabellen und vorhandenen Einzelrechte sind zu erhalten.
Die bisherige v2-Rechteauswertung bleibt bindend. Keine neue Verbindung nötig.

Der ausgeführte Pilot verwendete einen auf den bestätigten Ausgangsbaum
begrenzten Installer mit privater Quellen-/Datenbanksicherung, erneuter
Bestandsprüfung und Rückvergleich nach dem nativen Upgrade. Ein UI-Rückweg zur
bisherigen manuellen Oberfläche erhält das aktuelle Backend und seine Rechte.
Es erfolgt keine automatische Datenbankrücksetzung. Der konkrete private
Sicherungspfad ist nicht Bestandteil dieses öffentlichen Quellpakets.

Das veröffentlichte Archiv ist kein pauschaler Überschreibbefehl und kein
universeller Installer für ungeprüfte bestehende Installationen.

## Ausgang vor App 0.5.0

Einzelrechte benötigen seit0.5.0 die native Migration
`Version000500Date20261031190000` und Tabelle `ns_pf_tool_access`.
Bei einem älteren Ausgang muss dieser Unterschied im passenden nativen
Upgradeweg berücksichtigt werden; Quellen kopieren ersetzt keine Migration.
App und Online-Connector 1.37.0 verwenden denselben abgeleiteten Katalog.

## Praktische Stichprobe

Nach dem Update KI-Verbindungen neu laden. Die kurze Probe in
[LIVE-TEST.md](LIVE-TEST.md) prüft an einer bestehenden Testverbindung:
einzelnes Kommentar-Leserecht aus, „Gespeichert“ abwarten, neu laden und den
wirklich gesperrten MCP-Aufruf prüfen; dann wieder an, automatische Bestätigung,
Neuladen und wieder erlaubten Abruf prüfen. Unabhängiges Kartenlesen bleibt
währenddessen erlaubt. Für den ausgeführten Pilot sind3/3 bestätigt.

Die ältere Kontext-Statusschnittstelle enthält weiterhin den festen Wert0.4.0.
Die installierte Appversion wird anhand der Nextcloud-App-Metadaten und
`appinfo/info.xml` festgestellt; dieser alte Kontextwert ist kein Versionsnachweis.

## Historische Anleitung und Prüfungen der App 0.4.0

# Integration und Testinstallation

Dieses Dokument gehört zum App-Quellpaket vom 23. Oktober 2026. Es beschreibt den vorgesehenen Einbau und seine offenen Abnahmen. Das Paket ist noch kein freigegebenes Produktionsupdate. Der in [DEPLOYED_SOURCE_CHECK.json](DEPLOYED_SOURCE_CHECK.json) dokumentierte Vergleich aller 26 gemeldeten Betriebsdateien ist abgeschlossen; die frühere Metadatenabweichung ist aufgelöst. Die frische Neuinstallation wurde inzwischen für Nextcloud 34.0.4 und 35.0.0 mit PHP 8.3.6/MariaDB 10.11.14 erfolgreich geprüft. Der produktive Updatepfad bleibt gesondert abzunehmen.

## Voraussetzungen

- Eine getrennte Nextcloud-Testinstallation. Die belegten Betriebsmetadaten deklarieren die Hauptversionen **34–35**. Praktisch geprüft sind **34.0.4 und 35.0.0 mit PHP 8.3.6 und MariaDB 10.11.14**, jeweils 36/36 native Prüfungen. Andere Kombinationen sind damit nicht pauschal freigegeben.
- Ein App-Verzeichnis `novaspace_platform` in einem dafür konfigurierten beschreibbaren Nextcloud-App-Pfad. Der Inhalt von `app/` gehört unmittelbar hinein; `appinfo/info.xml` muss direkt darunter liegen.
- Bei Online-Anbindung ein eigener bestätigter Gateway-Kontext und eine persönliche Verbindung. Das Paket enthält keine funktionsfähigen fremden Vertrauensdaten oder Zugangsdaten.
- Für GitHub-Funktionen die passende vorhandene `deckgithubsync`-App und ein persönlich dort eingerichteter GitHub-Zugang. Die verwendeten Dienstschnittstellen sind in [app/lib/Service/GithubBridgeService.php](app/lib/Service/GithubBridgeService.php) sichtbar. Eine allgemeine Kompatibilitätsfreigabe für beliebige Versionen wird nicht behauptet.
- Der enthaltene Inventory-Adapter ist optional und auf den vorhandenen Stand `inventory` 0.1.5.1 sowie zwei konkrete Quelldateihashes begrenzt. Ohne die passende App beziehungsweise ohne ausdrückliche Freigabe stehen diese Operationen nicht bereit.

Nextcloud, `deckgithubsync` und Inventory werden nicht mitgeliefert. Ihre jeweiligen Lizenzbedingungen bleiben bestehen.

## Vorhandenen Betrieb erhalten

Dieses Quellpaket soll die bisherige Installation zunächst dokumentieren und in einer getrennten Umgebung geprüft werden. Es enthält keine pauschale Überschreib- oder Reparaturroutine für eine vorhandene App. Ein bestehender Ordner gleicher Versionsnummer darf nicht allein aufgrund der Nummer als identisch behandelt werden.

Vor einem späteren Produktionsupdate sind der aktuelle App-Baum, `appinfo/info.xml`, die persönliche Vertrauenskonfiguration, Aktivierungszustand und Datenbankschema frisch zu vergleichen. Quell- und Datenbanksicherungen sowie der konkrete Wiederherstellungsweg gehören zu dieser gesonderten Abnahme.

## Vertrauenskonfiguration

`app/appinfo/trusted-gateway.json` und `trusted-gateway.example.json` enthalten absichtlich inaktive Werte. Ein leerer `publicKey` erlaubt keine signierten Online-Aufrufe. Das Kopieren des Pakets übernimmt dadurch keine bestehende Verbindung und aktiviert keine Hintergrundsynchronisation.

Für eine eigene geprüfte Anbindung müssen die folgenden Werte aus dem tatsächlich verwendeten Gateway übernommen werden:

| Feld | Bedeutung |
|---|---|
| `kid` | Genau die Schlüsselkennung des verwendeten Signaturschlüssels |
| `issuer` | Genau der vom Gateway verwendete Aussteller |
| `audienceBase` | Vollständige eigene Basis der Registry-OCS-Adresse; einschließlich eines eventuell vorhandenen Nextcloud-Unterpfads |
| `publicKey` | Öffentlicher RSA-Schlüssel dieses Gateways im PEM-Format |
| `label` | Verständliche Bezeichnung für die persönliche Einrichtung |

Die Beispieladresse lautet `https://nextcloud.example.invalid/ocs/v2.php/apps/novaspace_platform/api/v1/registry`. Die Zwecke `setup`, `status`, `inventory` und `github` werden vom Prüfer selbst ergänzt. Ein öffentlicher Schlüssel ist kein Passwort. Private Signaturschlüssel und persönliche App-Passwörter gehören nicht in dieses Repository.

Das App-Paket bringt keine Einrichtung eines Online-Gateways und keinen vollständigen Online-Connector mit. Dafür werden die entsprechenden Komponenten und ihre eigenen Konfigurationen benötigt.

## Ablauf in einer frischen Testinstallation

1. Den Paketinhalt und die SHA-256-Nachweise prüfen; das App-Archiv zunächst außerhalb der Nextcloud-Installation entpacken.
2. Den App-Baum in den vorgesehenen Test-App-Pfad übernehmen. Es darf dort noch keine vorhandene App gleichen Namens und keine unerwarteten `ns_pf_*`-Tabellen geben.
3. Mit dem zur Testinstallation gehörenden PHP und dem dort üblichen technischen Konto `php occ app:enable novaspace_platform` ausführen. Dabei werden native Migrationen erwartet. Das erfolgreiche Kommando und die tatsächlich angelegten Tabellen müssen separat geprüft werden.
4. In einer persönlichen Websitzung die Seite „KI-Verbindungen“ öffnen. Ohne konfiguriertes Gateway kann noch keine signierte Online-Verbindung eingerichtet werden.
5. Erst mit einer bestätigten Test-Gateway-Konfiguration die persönliche Registrierung und begrenzte App-Freigabe prüfen. Der technische Aufrufer und der logische Eigentümer müssen dabei unterscheidbar bleiben.
6. Widerruf, ausgeschaltete Freigaben, falsche Identität, abgelaufene Signaturen und gleichzeitige Änderungen praktisch prüfen. GitHub-Schreibversuche gehören ausschließlich in ausdrücklich gewählte Testziele.

Die Migrationen legen die Registry-/Journal-, Inventory-Freigabe-/Journal- und App-Freigabetabellen an. Sie verweigern unerwartet bereits vorhandene Tabellen. Ein Testlauf ersetzt deshalb keinen geprüften Aktualisierungspfad für eine bestehende Installation.

## Abnahme und Rückweg

Die native Neuinstallationsprüfung einschließlich Datenbankmigrationen, HTTP/CSRF, persönlicher Freigabe, Widerruf und Webserver-Neustart ist für die beiden dokumentierten Kombinationen erfolgreich. [Testaufbau](integration/README.md) und [Ergebnisse](INTEGRATION_RESULTS.json) halten Umfang und Grenzen fest. Die isolierten Fixture-Prüfungen bleiben ein separater Nachweis.

Vor einem produktiven Update bleiben der konkrete bestehende Daten-/Quellstand, Sicherung/Wiederherstellung und der tatsächlich gewählte Updatepfad zu prüfen. Erfolgreiche Abläufe mit installierten externen Zusatz-Apps sowie weitere Laufzeit-/Webserverkombinationen werden gesondert abgenommen.

Ein Abschalten über Nextcloud widerruft nicht automatisch jeden bereits bestehenden externen Token. Vorhandene persönliche Verbindungen, externe Sync-Zuordnungen und deren Zeitpläne müssen entsprechend ihrem tatsächlichen Eigentümer und Betriebszustand getrennt behandelt werden. Daten und Journale werden nicht als Aufräummaßnahme gelöscht.
